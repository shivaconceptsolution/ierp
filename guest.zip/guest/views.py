from django.shortcuts import render
def index(request):
    return render(request,"guest/index.html")
def about(request):
    return render(request,"guest/about.html")
def contact(request):
    return render(request,"guest/contact.html")
def gallery(request):
    return render(request,"guest/gallery.html")
def services(request):
    return render(request,"guest/services.html")            