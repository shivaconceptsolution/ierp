from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    if request.method=="POST":
        a = request.POST["txtnum1"]
        b = request.POST["txtnum2"]
        a,b = b,a
        return render(request,"account/index.html",{"res":"a "+str(a) + " b = "+str(b)})
    else:    
       return render(request,"account/index.html")
