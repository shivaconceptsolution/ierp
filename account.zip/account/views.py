from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    if request.method=="POST":
        a = request.POST["txtnum1"]
        b = request.POST["txtnum2"]
        a,b = b,a
        return render(request,"account/index.html",{"res":"a "+str(a) + " b = "+str(b)})
    else:    
       return render(request,"account/index.html")
def si(request):
    if request.method=="POST":
       p = request.POST["txtp"]
       r = request.POST["txtr"]
       t = request.POST["txtt"]
       s = float(p)*float(r)*float(t)/100
       return render(request,"account/si.html",{"res":s,"p":p,"r":r,"t":t})
    else:
        return render(request,"account/si.html")

def changecolor(request):
    if request.method=="POST":
        c = request.POST["color"]
        return render(request,"account/changecolor.html",{"res":c})
    else:
        return render(request,"account/changecolor.html")         