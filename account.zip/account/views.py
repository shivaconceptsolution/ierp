from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    if request.method=="POST":
        a = request.POST["txtnum1"]
        b = request.POST["txtnum2"]
        a,b = b,a
        return render(request,"account/index.html",{"res":"a "+str(a) + " b = "+str(b)})
    else:    
       return render(request,"account/index.html")
def si(request):
    if request.method=="POST":
       p = request.POST["txtp"]
       r = request.POST["txtr"]
       t = request.POST["txtt"]
       s = float(p)*float(r)*float(t)/100
       return render(request,"account/si.html",{"res":s,"p":p,"r":r,"t":t})
    else:
        return render(request,"account/si.html")

def changecolor(request):
    if request.method=="POST":
        c = request.POST["color"]
        return render(request,"account/changecolor.html",{"res":c})
    else:
        return render(request,"account/changecolor.html")         


def checkbox(request):
    if request.method == "POST":
        c = request.POST.getlist("course[]")
        s = ""
        for data in c:
            s = s + data + " "
        return render(request,"account/checkbox.html",{"res":s})
    else:
        return render(request,"account/checkbox.html")


def dropdownlist(request):
    if request.method=="POST":
        s = request.POST["course"]
        return render(request,"account/dropdown.html",{"res":s})
    else:
        return render(request,"account/dropdown.html")


def listbox(request):
    if request.method == "POST":
        c = request.POST.getlist("course[]")
        s = ""
        for data in c:
            s = s + data + " "
        return render(request,"account/listbox.html",{"res":s})
    else:
        return render(request,"account/listbox.html")        



def checkevenoddjinja(request):
     num =5
     return render(request,"account/checkeven.html",{"res":num})       

def table(request):
     num =5
     x=[]
     for i in range(1,11):
         x.append(num*i)
     return render(request,"account/table.html",{"res":x})     