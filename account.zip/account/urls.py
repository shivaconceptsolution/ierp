from django.urls import path
from . import views
urlpatterns=[
path('index',views.index,name='index'),
path('si',views.si,name='si'),
path('radio',views.changecolor,name='changecolor'),
path('checkbox',views.checkbox,name='checkbox'),
path('dropdownlist',views.dropdownlist,name='dropdownlist'),
path('listbox',views.listbox,name='listbox'),
path('checkevenoddjinja',views.checkevenoddjinja,name='checkevenoddjinja'),
path('',views.table,name='table')


]